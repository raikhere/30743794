Project Overview
The Inventory Management System is implemented using Oracle SQL and PL/SQL. It is designed to manage product details, supplier information, and product orders, with key functionalities for restocking products and processing orders efficiently.

Setup Instructions
Unzip the 30743794.zip file:

The zip file contains three main SQL scripts:
Database_schema.sql
PL-SQL_procedures.sql
Populating_database.sql
Execute the Scripts:

Step 1: Run Database_schema.sql to create the required tables (Products, Suppliers, Orders).
Step 2: Run Populating_database.sql to insert sample data into the tables.
Step 3: Run PL-SQL_procedures.sql to create the procedures for managing product restocking and order processing.

Running Instructions
Restocking a Product:
Use the RESTOCK_PRODUCT procedure with the following syntax:

RESTOCK_PRODUCT(p_order_id);


Processing an Order:
Use the PROCESS_ORDER procedure with the following syntax:

PROCESS_ORDER(p_product_id, p_supplier_id, p_quantity_ordered);


30743794.zip Contents

Database_schema.sql: This script creates the tables necessary for the system (Products, Suppliers, and Orders).
Populating_database.sql: This script inserts sample records into the Products, Suppliers, and Orders tables to facilitate testing.
PL-SQL_procedures.sql: This script contains the PL/SQL procedures used for product restocking and order processing:
RESTOCK_PRODUCT updates product stock based on incoming orders.
PROCESS_ORDER handles the creation of new orders and adjusts stock levels accordingly.
